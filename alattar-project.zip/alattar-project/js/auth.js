const AUTHT = {
    ar: {
        login: "تسجيل الدخول",
        signup: "حساب جديد",
        email: "البريد الإلكتروني",
        password: "كلمة المرور",
        fullName: "الاسم الكامل",
        phone: "رقم الجوال",
        loginBtn: "دخول",
        signupBtn: "إنشاء الحساب",
        switchToSignup: "ما عندك حساب؟ سجّل واحد",
        switchToLogin: "عندك حساب؟ سجّل دخول",
        myOrders: "طلباتي",
        myRewards: "نقاطي",
        editProfile: "تعديل بياناتي",
        profileTitle: "بيانات الحساب",
        saveChanges: "حفظ التغييرات",
        profileSaved: "تم حفظ بياناتك بنجاح.",
        emailReadOnly: "البريد الإلكتروني لا يمكن تغييره من هنا",
        signupConfirmation: "تم إنشاء الحساب. افحص بريدك الإلكتروني واضغط على رابط التأكيد، وبعدها سجّل الدخول.",
        rewardsTitle: "نقاط العطّار",
        pointsBalance: "رصيد النقاط",
        pointsValue: "القيمة المتاحة",
        expires: "تنتهي",
        earnRule:
            "كل 1 د.أ = 1 نقطة، وكل 10 نقاط = 1 د.أ. النقاط صالحة لمدة 6 أشهر من تاريخ اكتسابها وتُضاف بعد تسليم الطلب.",
        noRewards: "ما في حركات نقاط بعد.",
        adminPanel: "لوحة التحكم",
        logout: "تسجيل خروج",
        orderHistTitle: "طلباتي السابقة",
        noOrders: "ما في طلبات سابقة بعد.",
        err: "صار خطأ، تأكد من البيانات وحاول مرة ثانية.",
        close: "إغلاق",
        orDivider: "أو",
        withGoogle: "المتابعة عبر Google",
        withFacebook: "المتابعة عبر Facebook",
        welcome: name => `أهلاً ${name || ""}`
    },

    en: {
        login: "Log in",
        signup: "Sign up",
        email: "Email",
        password: "Password",
        fullName: "Full name",
        phone: "Phone",
        loginBtn: "Log in",
        signupBtn: "Create account",
        switchToSignup: "No account? Sign up",
        switchToLogin: "Have an account? Log in",
        myOrders: "My Orders",
        myRewards: "My Rewards",
        editProfile: "Edit profile",
        profileTitle: "Account details",
        saveChanges: "Save changes",
        profileSaved: "Your profile was updated successfully.",
        emailReadOnly: "Email cannot be changed here",
        signupConfirmation: "Account created. Check your email and confirm your account, then log in.",
        rewardsTitle: "Al-Attar Points",
        pointsBalance: "Points balance",
        pointsValue: "Available value",
        expires: "Expires",
        earnRule:
            "Every 1 JD = 1 point, and every 10 points = 1 JD. Points are valid for 6 months from the date earned and are added after order delivery.",
        noRewards: "No points activity yet.",
        adminPanel: "Admin Panel",
        logout: "Log out",
        orderHistTitle: "My past orders",
        noOrders: "No past orders yet.",
        err: "Something went wrong, check your info and try again.",
        close: "Close",
        orDivider: "or",
        withGoogle: "Continue with Google",
        withFacebook: "Continue with Facebook",
        welcome: name => `Hi ${name || ""}`
    }
};


function authLang() {

    try {

        return (
            localStorage.getItem("attar_lang") ||
            "ar"
        );

    } catch (e) {

        return "ar";
    }
}


const at = () => AUTHT[authLang()];


function authEsc(value) {

    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


const AUS = {

    view: "closed",

    mode: "login",

    busy: false,

    err: "",

    msg: "",

    orders: null,

    rewards: null,

    rewardTx: null

};


function authRoot() {

    let root =
        document.getElementById("auth-root");


    if (!root) {

        root =
            document.createElement("div");

        root.id =
            "auth-root";

        document.body.appendChild(root);
    }


    return root;
}


async function authRefreshProfile() {

    if (
        !window.AUTH ||
        !window.AUTH.user
    ) {

        return null;
    }


    try {

        const {
            data,
            error
        } = await sb

            .from("profiles")

            .select("*")

            .eq(
                "id",
                window.AUTH.user.id
            )

            .single();


        if (error) {

            console.error(
                "profile refresh error:",
                error
            );

            return (
                window.AUTH.profile ||
                null
            );
        }


        window.AUTH.profile =
            data || null;


        return window.AUTH.profile;


    } catch (err) {

        console.error(
            "profile refresh exception:",
            err
        );


        return (
            window.AUTH.profile ||
            null
        );
    }
}


function authRender() {

    const root =
        authRoot();

    const T =
        at();


    if (
        AUS.view === "closed"
    ) {

        root.innerHTML = "";

        return;
    }


    if (
        AUS.view === "menu"
    ) {

        const name =

            window.AUTH.profile?.full_name ||

            window.AUTH.user?.email ||

            "";


        const role =
            window.AUTH.profile?.role;


        const isStaff =

            role === "admin" ||

            role === "manager";


        root.innerHTML = `

      <div
        class="auth-ov"
        onclick="authUI.close()">
      </div>


      <div class="auth-menu">

        <div class="auth-menu-hi">

          ${authEsc(
            T.welcome(name)
        )}

        </div>


        <button
          class="auth-menu-item"
          onclick="authUI.openProfile()">

          👤 ${T.editProfile}

        </button>


        <button
          class="auth-menu-item"
          onclick="authUI.openOrders()">

          📦 ${T.myOrders}

        </button>


        <button
          class="auth-menu-item"
          onclick="authUI.openRewards()">

          🌿 ${T.myRewards}

        </button>


        ${
            isStaff

                ? `

              <a
                class="auth-menu-item"
                href="admin.html">

                🛠️ ${T.adminPanel}

              </a>

            `

                : ""
        }


        <button
          class="auth-menu-item danger"
          onclick="authUI.logout()">

          ↪ ${T.logout}

        </button>

      </div>
    `;


        return;
    }


    if (
        AUS.view === "profile"
    ) {

        const profile =
            window.AUTH.profile || {};


        const email =

            window.AUTH.user?.email ||

            profile.email ||

            "";


        root.innerHTML = `

      <div
        class="auth-ov"
        onclick="authUI.close()">
      </div>


      <div
        class="auth-panel profile-panel">


        <div class="auth-panel-head">

          <b>
            ${T.profileTitle}
          </b>


          <button
            class="auth-x"
            onclick="authUI.close()">

            ✕

          </button>

        </div>


        <div class="auth-panel-body">


          ${
            AUS.err

                ? `

                <div class="auth-err">

                  ${authEsc(AUS.err)}

                </div>

              `

                : ""
        }


          ${
            AUS.msg

                ? `

                <div class="auth-ok">

                  ${authEsc(AUS.msg)}

                </div>

              `

                : ""
        }


          <form
            onsubmit="authUI.saveProfile(event)">


            <label
              class="auth-label"
              for="ap-name">

              ${T.fullName}

            </label>


            <input
              class="auth-field"
              id="ap-name"
              type="text"
              value="${authEsc(
            profile.full_name || ""
        )}"
              placeholder="${T.fullName}"
              maxlength="120">


            <label
              class="auth-label"
              for="ap-phone">

              ${T.phone}

            </label>


            <input
              class="auth-field"
              id="ap-phone"
              type="tel"
              value="${authEsc(
            profile.phone || ""
        )}"
              placeholder="${T.phone}"
              maxlength="40">
              <label
  class="auth-label"
  for="ap-address">

  ${authLang() === "ar"
            ? "العنوان"
            : "Address"}

</label>

<input
  class="auth-field"
  id="ap-address"
  type="text"
  value="${authEsc(
            profile.address || ""
        )}"
  placeholder="${
            authLang() === "ar"
                ? "العنوان"
                : "Address"
        }"
  maxlength="250">


            <label
              class="auth-label"
              for="ap-email">

              ${T.email}

            </label>


            <input
              class="auth-field auth-field-readonly"
              id="ap-email"
              type="email"
              value="${authEsc(email)}"
              readonly
              aria-readonly="true">


            <div class="auth-help">

              ${T.emailReadOnly}

            </div>


            <button
              type="submit"
              class="auth-submit"
              ${AUS.busy
            ? "disabled"
            : ""}>

              ${
            AUS.busy
                ? "…"
                : T.saveChanges
        }

            </button>

          </form>

        </div>

      </div>
    `;


        return;
    }


    if (
        AUS.view === "orders"
    ) {

        let body = "";


        if (
            AUS.orders === null
        ) {

            body = `

        <div class="auth-loading">

          …

        </div>
      `;

        }

        else if (
            AUS.orders.length === 0
        ) {

            body = `

        <div class="auth-empty">

          ${T.noOrders}

        </div>
      `;

        }

        else {

            body =
                AUS.orders
                    .map(order => {


                        const itemsHtml =

                            (order.order_items || [])

                                .map(item => {


                                    const itemName =

                                        authLang() === "ar"

                                            ? item.name_ar

                                            : item.name_en;


                                    return `

                    <div class="oi-row">

                      <span>

                        ${authEsc(itemName)}
                        ×
                        ${Number(item.qty || 0)}

                      </span>


                      <span>

                        ${
                                        Number(
                                            Number(item.price || 0) *
                                            Number(item.qty || 0)
                                        )
                                            .toFixed(2)
                                    }

                      </span>

                    </div>
                  `;

                                })

                                .join("");


                        const pointsUsed =

                            Number(
                                order.loyalty_points_redeemed ||
                                0
                            );


                        const pointsDiscount =

                            Number(
                                order.loyalty_discount ||
                                0
                            );


                        const pointsEarned =

                            Number(
                                order.loyalty_points_earned ||
                                0
                            );


                        return `

              <div class="order-card">


                <div class="order-card-h">

                  <b>

                    #${authEsc(
                            String(order.id || "")
                                .slice(0, 8)
                        )}

                  </b>


                  <span
                    class="order-status s-${authEsc(
                            order.status || ""
                        )}">

                    ${authEsc(
                            order.status || ""
                        )}

                  </span>

                </div>


                <div class="order-card-items">

                  ${itemsHtml}

                </div>


                ${
                            pointsUsed > 0

                                ? `

                      <div class="oi-row">

                        <span>

                          ${
                                    authLang() === "ar"
                                        ? "نقاط مستخدمة"
                                        : "Points used"
                                }

                        </span>

                        <span>

                          -${pointsUsed}

                        </span>

                      </div>

                    `

                                : ""
                        }


                ${
                            pointsDiscount > 0

                                ? `

                      <div class="oi-row">

                        <span>

                          ${
                                    authLang() === "ar"
                                        ? "خصم النقاط"
                                        : "Points discount"
                                }

                        </span>

                        <span>

                          -${pointsDiscount.toFixed(2)}

                        </span>

                      </div>

                    `

                                : ""
                        }


                ${
                            pointsEarned > 0

                                ? `

                      <div class="oi-row">

                        <span>

                          ${
                                    authLang() === "ar"
                                        ? "نقاط مكتسبة"
                                        : "Points earned"
                                }

                        </span>

                        <span>

                          +${pointsEarned}

                        </span>

                      </div>

                    `

                                : ""
                        }


                <div class="order-card-total">

                  <span>

                    ${
                            authLang() === "ar"
                                ? "الإجمالي"
                                : "Total"
                        }

                  </span>


                  <b>

                    ${
                            Number(
                                order.total || 0
                            ).toFixed(2)
                        }

                  </b>

                </div>

              </div>
            `;

                    })

                    .join("");
        }


        root.innerHTML = `

      <div
        class="auth-ov"
        onclick="authUI.close()">
      </div>


      <div class="auth-panel">


        <div class="auth-panel-head">

          <b>

            ${T.orderHistTitle}

          </b>


          <button
            class="auth-x"
            onclick="authUI.close()">

            ✕

          </button>

        </div>


        <div class="auth-panel-body">

          ${body}

        </div>

      </div>
    `;


        return;
    }


    if (
        AUS.view === "rewards"
    ) {

        const rewards =
            AUS.rewards;


        const tx =
            AUS.rewardTx;


        const value =

            rewards

                ? Number(
                    rewards.value_jod || 0
                ).toFixed(2)

                : "0.00";


        const expiry =

            rewards?.next_expiry

                ? new Date(
                    rewards.next_expiry
                )
                    .toLocaleDateString(

                        authLang() === "ar"
                            ? "ar-JO"
                            : "en-GB",

                        {
                            year: "numeric",
                            month: "short",
                            day: "numeric"
                        }

                    )

                : null;


        const labels = {

            earned:
                authLang() === "ar"
                    ? "مكتسبة"
                    : "Earned",

            redeemed:
                authLang() === "ar"
                    ? "مستخدمة"
                    : "Redeemed",

            refund:
                authLang() === "ar"
                    ? "مسترجعة"
                    : "Refunded",

            expired:
                authLang() === "ar"
                    ? "منتهية"
                    : "Expired",

            adjustment:
                authLang() === "ar"
                    ? "تعديل"
                    : "Adjustment"

        };


        let txHtml = "";


        if (
            tx === null
        ) {

            txHtml = `

        <div class="auth-loading">

          …

        </div>
      `;

        }

        else if (
            tx.length === 0
        ) {

            txHtml = `

        <div class="auth-empty">

          ${T.noRewards}

        </div>
      `;

        }

        else {

            txHtml =

                tx
                    .map(item => {


                        const points =
                            Number(item.points || 0);


                        const created =

                            new Date(
                                item.created_at
                            )
                                .toLocaleDateString(

                                    authLang() === "ar"
                                        ? "ar-JO"
                                        : "en-GB"

                                );


                        let expiryText = "";


                        if (
                            item.type === "earned" &&
                            item.expires_at
                        ) {

                            expiryText = `

                · ${T.expires}

                ${
                                new Date(
                                    item.expires_at
                                )
                                    .toLocaleDateString(

                                        authLang() === "ar"
                                            ? "ar-JO"
                                            : "en-GB"

                                    )
                            }
              `;
                        }


                        return `

              <div class="reward-tx">

                <div>

                  <b>

                    ${
                            authEsc(
                                labels[item.type] ||
                                item.type
                            )
                        }

                  </b>


                  <span>

                    ${created}
                    ${expiryText}

                  </span>

                </div>


                <strong
                  class="${
                            points >= 0
                                ? "plus"
                                : "minus"
                        }">

                  ${
                            points >= 0
                                ? "+"
                                : ""
                        }

                  ${points}

                </strong>

              </div>
            `;

                    })

                    .join("");
        }


        root.innerHTML = `

      <div
        class="auth-ov"
        onclick="authUI.close()">
      </div>


      <div
        class="auth-panel rewards-panel">


        <div class="auth-panel-head">

          <b>

            ${T.rewardsTitle}

          </b>


          <button
            class="auth-x"
            onclick="authUI.close()">

            ✕

          </button>

        </div>


        <div class="auth-panel-body">


          ${
            rewards === null

                ? `

                <div class="auth-loading">

                  …

                </div>

              `

                : `

                <div class="reward-balance">


                  <div>

                    <span>

                      ${T.pointsBalance}

                    </span>


                    <b>

                      ${
                    Number(
                        rewards.points || 0
                    )
                }
                      pts

                    </b>

                  </div>


                  <div>

                    <span>

                      ${T.pointsValue}

                    </span>


                    <b>

                      ${value}

                      ${
                    authLang() === "ar"
                        ? "د.أ"
                        : "JD"
                }

                    </b>

                  </div>

                </div>


                ${
                    expiry &&
                    Number(
                        rewards.next_expiry_points ||
                        0
                    ) > 0

                        ? `

                      <div class="reward-expiry">

                        ⏳

                        ${
                            rewards.next_expiry_points
                        }

                        ${
                            authLang() === "ar"
                                ? "نقطة"
                                : "points"
                        }

                        ${T.expires}

                        ${expiry}

                      </div>

                    `

                        : ""
                }


                <div class="reward-rule">

                  ${T.earnRule}

                </div>

              `
        }


          <div class="reward-history">

            ${txHtml}

          </div>

        </div>

      </div>
    `;


        return;
    }


    const isSignup =
        AUS.mode === "signup";


    root.innerHTML = `

    <div
      class="auth-ov"
      onclick="authUI.close()">
    </div>


    <div class="auth-panel">


      <div class="auth-panel-head">

        <b>

          ${
        isSignup
            ? T.signup
            : T.login
    }

        </b>


        <button
          class="auth-x"
          onclick="authUI.close()">

          ✕

        </button>

      </div>


      <div class="auth-panel-body">


        ${
        AUS.err

            ? `

              <div class="auth-err">

                ${authEsc(AUS.err)}

              </div>

            `

            : ""
    }


        ${
        AUS.msg

            ? `

              <div class="auth-ok">

                ${authEsc(AUS.msg)}

              </div>

            `

            : ""
    }


        <div class="auth-social">


          <button
            type="button"
            class="auth-social-btn google"
            onclick="authUI.oauth('google')">

            <img
              src="assets/img/google-icon.svg"
              alt=""
              onerror="this.style.display='none'">

            ${T.withGoogle}

          </button>


          <button
            type="button"
            class="auth-social-btn facebook"
            onclick="authUI.oauth('facebook')">

            <img
              src="assets/img/facebook-icon.svg"
              alt=""
              onerror="this.style.display='none'">

            ${T.withFacebook}

          </button>

        </div>


        <div class="auth-or">

          <span>

            ${T.orDivider}

          </span>

        </div>


        <form
          onsubmit="authUI.submit(event)">


          ${
        isSignup

            ? `

                <input
                  class="auth-field"
                  id="af-name"
                  type="text"
                  placeholder="${T.fullName}"
                  maxlength="120"
                  required>

              `

            : ""
    }


          <input
            class="auth-field"
            id="af-email"
            type="email"
            placeholder="${T.email}"
            required>


          <input
            class="auth-field"
            id="af-pass"
            type="password"
            placeholder="${T.password}"
            minlength="6"
            required>


          ${
        isSignup

            ? `

                <input
                  class="auth-field"
                  id="af-phone"
                  type="tel"
                  maxlength="40"
                  placeholder="${T.phone}">

              `

            : ""
    }


          <button
            type="submit"
            class="auth-submit"
            ${AUS.busy
        ? "disabled"
        : ""}>

            ${
        AUS.busy

            ? "…"

            : (
                isSignup

                    ? T.signupBtn

                    : T.loginBtn
            )
    }

          </button>

        </form>


        <button
          type="button"
          class="auth-switch"
          onclick="authUI.toggleMode()">

          ${
        isSignup

            ? T.switchToLogin

            : T.switchToSignup
    }

        </button>

      </div>

    </div>
  `;
}


window.authUI = {


    async open() {

        AUS.err = "";
        AUS.msg = "";


        if (
            !window.AUTH ||
            !window.AUTH.user
        ) {

            AUS.view =
                "login";

            AUS.mode =
                "login";

            authRender();

            return;
        }


        const root =
            authRoot();


        root.innerHTML = `

      <div
        class="auth-ov"
        onclick="authUI.close()">
      </div>


      <div class="auth-menu">

        <div class="auth-loading">

          …

        </div>

      </div>
    `;


        await authRefreshProfile();


        AUS.view =
            "menu";

        AUS.mode =
            "login";


        authRender();
    },


    close() {

        AUS.view =
            "closed";

        AUS.err =
            "";

        AUS.msg =
            "";

        authRender();
    },


    toggleMode() {

        AUS.mode =

            AUS.mode === "login"

                ? "signup"

                : "login";


        AUS.err =
            "";

        AUS.msg =
            "";


        authRender();
    },


    async oauth(provider) {

        AUS.err =
            "";

        AUS.msg =
            "";

        AUS.busy =
            true;


        authRender();


        try {

            const {
                error
            } = await sb.auth

                .signInWithOAuth({

                    provider,

                    options: {

                        redirectTo:
                        window.location.href

                    }

                });


            if (error) {

                throw error;
            }


        } catch (err) {

            AUS.busy =
                false;

            AUS.err =

                err?.message ||

                at().err;


            console.error(
                "OAuth error:",
                err
            );


            authRender();
        }
    },


    async submit(event) {

        event.preventDefault();


        const email =
            document
                .getElementById("af-email")
                ?.value
                .trim() || "";


        const password =
            document
                .getElementById("af-pass")
                ?.value || "";


        const name =

            AUS.mode === "signup"

                ? (
                    document
                        .getElementById("af-name")
                        ?.value
                        .trim() ||
                    ""
                )

                : "";


        const phone =

            AUS.mode === "signup"

                ? (
                    document
                        .getElementById("af-phone")
                        ?.value
                        .trim() ||
                    ""
                )

                : "";


        AUS.busy =
            true;

        AUS.err =
            "";

        AUS.msg =
            "";


        authRender();


        try {


            if (
                AUS.mode === "signup"
            ) {

                const {
                    data,
                    error
                } = await sb.auth

                    .signUp({

                        email,

                        password,

                        options: {

                            data: {

                                full_name:
                                name,

                                phone:
                                    phone || null

                            }

                        }

                    });


                if (error) {

                    throw error;
                }


                /*
                  IMPORTANT:
                  data.user can exist even when confirmation
                  is required.

                  Only data.session means the browser is
                  actually authenticated.
                */

                if (
                    data?.session?.user
                ) {

                    window.AUTH.user =
                        data.session.user;


                    await authRefreshProfile();


                    if (
                        phone
                    ) {

                        const {
                            error: phoneError
                        } = await sb

                            .from("profiles")

                            .update({

                                phone

                            })

                            .eq(
                                "id",
                                data.session.user.id
                            );


                        if (phoneError) {

                            console.warn(
                                "phone profile update error:",
                                phoneError
                            );

                        } else {

                            await authRefreshProfile();
                        }
                    }

                } else {

                    /*
                      Confirmation email required.

                      Do NOT set AUTH.user using data.user.
                      Without data.session, the customer is
                      not logged in yet.
                    */

                    window.AUTH.user =
                        null;

                    window.AUTH.profile =
                        null;


                    AUS.busy =
                        false;

                    AUS.mode =
                        "login";

                    AUS.err =
                        "";

                    AUS.msg =
                        at().signupConfirmation;


                    authUpdateIcon();

                    authRender();

                    return;
                }

            }


            else {

                const {
                    error
                } = await sb.auth

                    .signInWithPassword({

                        email,

                        password

                    });


                if (error) {

                    throw error;
                }


                const {
                    data: {
                        user
                    }
                } = await sb.auth

                    .getUser();


                if (
                    user
                ) {

                    window.AUTH.user =
                        user;


                    await authRefreshProfile();


                    /*
                      The signup phone is stored in Auth metadata.

                      When confirmation was required, we could not
                      update public.profiles before login because
                      there was no authenticated session.

                      On the first real login, copy that phone into
                      the profile if it is still empty.
                    */

                    const signupPhone =

                        String(
                            user.user_metadata?.phone || ""
                        ).trim();


                    if (
                        signupPhone &&
                        !window.AUTH.profile?.phone
                    ) {

                        const {
                            error: phoneError
                        } = await sb

                            .from("profiles")

                            .update({

                                phone:
                                signupPhone

                            })

                            .eq(
                                "id",
                                user.id
                            );


                        if (phoneError) {

                            console.warn(
                                "signup phone sync error:",
                                phoneError
                            );

                        } else {

                            await authRefreshProfile();
                        }
                    }
                }
            }


            AUS.busy =
                false;

            AUS.view =
                "closed";


            authRender();


        } catch (err) {

            AUS.busy =
                false;


            AUS.err =

                err?.message ||

                at().err;


            console.error(
                "auth error:",
                err
            );


            authRender();
        }
    },


    async logout() {

        try {

            const {
                error
            } = await sb.auth

                .signOut();


            if (error) {

                throw error;
            }


        } catch (err) {

            console.error(
                "logout error:",
                err
            );

        } finally {

            window.AUTH.user =
                null;

            window.AUTH.profile =
                null;


            AUS.view =
                "closed";

            AUS.err =
                "";

            AUS.msg =
                "";


            authRender();


            authUpdateIcon();
        }
    },


    async openProfile() {

        AUS.err =
            "";

        AUS.msg =
            "";

        AUS.busy =
            false;


        if (
            !window.AUTH?.user
        ) {

            AUS.view =
                "login";

            AUS.mode =
                "login";

            authRender();

            return;
        }


        await authRefreshProfile();


        AUS.view =
            "profile";


        authRender();
    },


    async saveProfile(event) {

        event.preventDefault();


        if (
            !window.AUTH?.user
        ) {

            AUS.view =
                "login";

            AUS.mode =
                "login";

            authRender();

            return;
        }


        const fullName =

            document
                .getElementById("ap-name")
                ?.value
                .trim() || "";


        const phone =

            document
                .getElementById("ap-phone")
                ?.value
                .trim() || "";
        const address =
            document
                .getElementById("ap-address")
                ?.value
                .trim() || "";


        AUS.busy =
            true;

        AUS.err =
            "";

        AUS.msg =
            "";


        authRender();


        try {

            const {
                error
            } = await sb

                .from("profiles")

                .update({

                    full_name:
                        fullName || null,

                    phone:
                        phone || null,

                    address:
                        address || null

                })

                .eq(
                    "id",
                    window.AUTH.user.id
                );


            if (error) {

                throw error;
            }


            await authRefreshProfile();


            AUS.busy =
                false;


            AUS.msg =
                at().profileSaved;


            authRender();


            document.dispatchEvent(

                new CustomEvent(
                    "profile-updated"
                )

            );


        } catch (err) {

            AUS.busy =
                false;


            AUS.err =

                err?.message ||

                at().err;


            console.error(
                "profile update error:",
                err
            );


            authRender();
        }
    },


    async openOrders() {

        if (
            !window.AUTH?.user
        ) {

            AUS.view =
                "login";

            authRender();

            return;
        }


        AUS.view =
            "orders";

        AUS.orders =
            null;

        AUS.err =
            "";

        AUS.msg =
            "";


        authRender();


        try {

            const {
                data,
                error
            } = await sb

                .from("orders")

                .select(`
          id,
          status,
          total,
          loyalty_points_earned,
          loyalty_points_redeemed,
          loyalty_discount,
          created_at,
          order_items(
            name_ar,
            name_en,
            price,
            qty
          )
        `)

                .order(
                    "created_at",
                    {
                        ascending: false
                    }
                );


            if (error) {

                throw error;
            }


            AUS.orders =
                data || [];


        } catch (err) {

            console.error(
                "orders load error:",
                err
            );


            AUS.orders =
                [];
        }


        authRender();
    },


    async openRewards() {

        if (
            !window.AUTH?.user
        ) {

            AUS.view =
                "login";

            authRender();

            return;
        }


        AUS.view =
            "rewards";

        AUS.rewards =
            null;

        AUS.rewardTx =
            null;

        AUS.err =
            "";

        AUS.msg =
            "";


        authRender();


        try {

            const [
                summary,
                history
            ] = await Promise.all([


                sb.rpc(
                    "get_loyalty_summary"
                ),


                sb

                    .from(
                        "loyalty_transactions"
                    )

                    .select(`
            id,
            type,
            points,
            note,
            created_at,
            expires_at
          `)

                    .order(
                        "created_at",
                        {
                            ascending: false
                        }
                    )

                    .limit(50)

            ]);


            if (
                summary.error
            ) {

                console.error(
                    "loyalty summary error:",
                    summary.error
                );


                AUS.rewards = {

                    points: 0,

                    value_jod: 0,

                    next_expiry: null,

                    next_expiry_points: 0

                };

            }

            else {

                AUS.rewards =

                    Array.isArray(
                        summary.data
                    )

                        ? (
                            summary.data[0] ||
                            {
                                points: 0,
                                value_jod: 0,
                                next_expiry: null,
                                next_expiry_points: 0
                            }
                        )

                        : (
                            summary.data ||
                            {
                                points: 0,
                                value_jod: 0,
                                next_expiry: null,
                                next_expiry_points: 0
                            }
                        );
            }


            if (
                history.error
            ) {

                console.error(
                    "loyalty history error:",
                    history.error
                );


                AUS.rewardTx =
                    [];

            }

            else {

                AUS.rewardTx =
                    history.data || [];
            }


            if (
                window.AUTH.profile &&
                AUS.rewards
            ) {

                window.AUTH.profile.loyalty_points =

                    Number(
                        AUS.rewards.points ||
                        0
                    );
            }


        } catch (err) {

            console.error(
                "rewards load exception:",
                err
            );


            AUS.rewards = {

                points: 0,

                value_jod: 0,

                next_expiry: null,

                next_expiry_points: 0

            };


            AUS.rewardTx =
                [];
        }


        authRender();
    }

};


document.addEventListener(

    "auth-changed",

    async () => {


        if (
            window.AUTH &&
            window.AUTH.user
        ) {

            await authRefreshProfile();
        }


        if (
            AUS.view === "menu" ||
            AUS.view === "profile"
        ) {

            authRender();
        }


        authUpdateIcon();

    }

);


document.addEventListener(

    "profile-updated",

    () => {

        authUpdateIcon();

    }

);


function authUpdateIcon() {

    document

        .querySelectorAll(
            ".accounticon"
        )

        .forEach(button => {

            button.classList.toggle(

                "logged-in",

                !!window.AUTH?.user

            );

        });
}


authUpdateIcon();