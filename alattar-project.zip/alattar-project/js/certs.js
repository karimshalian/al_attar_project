/* Al-Attar — certs.js
   Certification badges/cards and certification details.
*/

let CERTS=[];
let CERTS_LOADED=false;


function certEsc(value){

  return String(value??"")

      .replace(
          /&/g,
          "&amp;"
      )

      .replace(
          /</g,
          "&lt;"
      )

      .replace(
          />/g,
          "&gt;"
      )

      .replace(
          /"/g,
          "&quot;"
      )

      .replace(
          /'/g,
          "&#039;"
      );
}


function certSafeUrl(value){

  const raw=
      String(value??"")
          .trim();


  if(!raw){

    return "";
  }


  try{

    const url=
        new URL(
            raw,
            window.location.origin
        );


    if(
        url.protocol!=="http:" &&
        url.protocol!=="https:"
    ){

      return "";
    }


    return url.href;


  }catch(e){

    return "";
  }
}


function certDomId(id){

  const safe=
      String(id??"")

          .replace(
              /[^a-zA-Z0-9_-]/g,
              ""
          );


  return (
      "cert-"+
      safe
  );
}


async function certsLoad(){

  const {
    data,
    error
  }=
      await sb

          .from(
              "certifications"
          )

          .select("*")

          .eq(
              "active",
              true
          )

          .order(
              "sort_order",
              {
                ascending:true
              }
          );


  if(error){

    console.error(
        "certifications load error:",
        error
    );

    return;
  }


  CERTS=
      (data||[])

          .map(
              row=>({

                id:
                row.id,


                logo:

                    row.logo_url ||

                    (
                        row.images &&
                        row.images[0]
                    )

                    ||null,


                pdfs:

                    row.pdfs &&
                    row.pdfs.length

                        ?row.pdfs

                        :(row.images||[])
                            .map(
                                url=>({

                                  label:"",

                                  url

                                })
                            ),


                ar:{

                  name:
                  row.name_ar,

                  issuer:
                  row.issuer,

                  lines:
                      row.details_ar||
                      []

                },


                en:{

                  name:
                  row.name_en,

                  issuer:
                  row.issuer,

                  lines:
                      row.details_en||
                      []

                }

              })
          );


  CERTS_LOADED=
      true;


  certsRefreshDOM();

  certsScrollToHash();
}


function certsLang(){

  try{

    return (
        localStorage.getItem(
            "attar_lang"
        ) ||
        "ar"
    );

  }catch(e){

    return "ar";
  }
}


function certsLinkFor(id){

  return (
      "certifications.html#"+
      certDomId(id)
  );
}


function certsRowHtml(mode){

  mode=
      mode||
      "badges";


  if(!CERTS_LOADED){

    return (

        mode==="cards"

            ?`
              <div
                class="cert-grid cert-grid-loading"
                data-cert-mode="cards">
              </div>
            `

            :`
              <div
                class="cert-row cert-row-loading"
                data-cert-mode="badges">
              </div>
            `
    );
  }


  if(!CERTS.length){

    return (

        mode==="cards"

            ?`
              <div
                class="cert-grid"
                data-cert-mode="cards">
              </div>
            `

            :`
              <div
                class="cert-row"
                data-cert-mode="badges">
              </div>
            `
    );
  }


  if(
      mode==="cards"
  ){

    return `
      <div
        class="cert-grid"
        data-cert-mode="cards">


        ${
        CERTS

            .map(
                c=>{

                  const t=
                      c[
                          certsLang()
                          ];


                  const logo=
                      certSafeUrl(
                          c.logo
                      );


                  return `
                      <a
                        class="cert-card"
                        href="${
                      certEsc(
                          certsLinkFor(
                              c.id
                          )
                      )
                  }">


                        ${
                      logo

                          ?`
                                <img
                                  src="${certEsc(logo)}"
                                  alt="${certEsc(t.name)}"
                                  loading="lazy">
                              `

                          :`
                                <span class="cert-card-ic">
                                  🏅
                                </span>
                              `
                  }


                        <div class="t">

                          ${
                      certEsc(
                          t.name
                      )
                  }

                        </div>


                        <div class="d">

                          ${
                      certEsc(
                          t.issuer
                      )
                  }

                        </div>

                      </a>
                    `;
                }
            )

            .join("")
    }

      </div>
    `;
  }


  return `
    <div
      class="cert-row"
      data-cert-mode="badges">


      ${
      CERTS

          .map(
              c=>{

                const t=
                    c[
                        certsLang()
                        ];


                const logo=
                    certSafeUrl(
                        c.logo
                    );


                return `
                    <a
                      class="cert-badge"
                      href="${
                    certEsc(
                        certsLinkFor(
                            c.id
                        )
                    )
                }"
                      aria-label="${
                    certEsc(
                        t.name
                    )
                }">


                      ${
                    logo

                        ?`
                              <img
                                src="${certEsc(logo)}"
                                alt="${certEsc(t.name)}"
                                loading="lazy">
                            `

                        :`
                              <span class="cert-badge-ic">
                                🏅
                              </span>
                            `
                }

                    </a>
                  `;
              }
          )

          .join("")
  }

    </div>
  `;
}


function certsRefreshDOM(){

  document

      .querySelectorAll(
          ".cert-row, .cert-grid"
      )

      .forEach(
          el=>{

            const mode=
                el.dataset.certMode||
                "badges";


            el.outerHTML=
                certsRowHtml(
                    mode
                );
          }
      );


  certsRenderDetailRoot();
}


function certsRenderDetailRoot(){

  const root=
      document.getElementById(
          "certs-detail-root"
      );


  if(!root){

    return;
  }


  if(!CERTS_LOADED){

    root.innerHTML=`
      <div class="cert-detail-loading">
      </div>
    `;

    return;
  }


  root.innerHTML=
      CERTS

          .map(
              c=>{

                const t=
                    c[
                        certsLang()
                        ];


                return `

                  <article
                    class="cert-detail"
                    id="${
                    certEsc(
                        certDomId(
                            c.id
                        )
                    )
                }">


                    <div class="cert-detail-head">

                      <h3>

                        ${
                    certEsc(
                        t.name
                    )
                }

                      </h3>


                      <span>

                        ${
                    certEsc(
                        t.issuer
                    )
                }

                      </span>

                    </div>


                    <ul class="cert-facts">

                      ${
                    (t.lines||[])

                        .map(
                            line=>`

                                  <li>
                                    ${certEsc(line)}
                                  </li>

                                `
                        )

                        .join("")
                }

                    </ul>


                    <div class="cert-detail-docs">


                      ${
                    (c.pdfs||[])

                        .map(
                            p=>{

                              const url=
                                  certSafeUrl(
                                      p?.url
                                  );


                              if(!url){

                                return "";
                              }


                              return `

                                    <div class="cert-doc">


                                      ${
                                  p?.label

                                      ?`
                                              <div class="cert-doc-label">

                                                ${
                                          certEsc(
                                              p.label
                                          )
                                      }

                                              </div>
                                            `

                                      :""
                              }


                                      <div class="cert-doc-frame">


                                        <iframe
                                          src="${certEsc(url)}#toolbar=0&navpanes=0"
                                          loading="lazy">
                                        </iframe>


                                        <button
                                          class="cert-doc-expand"
                                          type="button"
                                          data-cert-url="${certEsc(url)}"
                                          onclick="certsUI.expandButton(this)"
                                          aria-label="تكبير">

                                          ⤢

                                        </button>


                                      </div>

                                    </div>
                                  `;
                            }
                        )

                        .join("")
                }

                    </div>

                  </article>
                `;
              }
          )

          .join("");
}


function certsScrollToHash(){

  if(
      !location.hash.startsWith(
          "#cert-"
      )
  ){

    return;
  }


  const id=
      location.hash
          .slice(1);


  const el=
      document.getElementById(
          id
      );


  if(!el){

    return;
  }


  el.scrollIntoView({

    behavior:
        "smooth",

    block:
        "start"

  });


  el.classList.add(
      "cert-detail-highlight"
  );


  setTimeout(

      ()=>
          el.classList.remove(
              "cert-detail-highlight"
          ),

      2200
  );
}


window.certsUI={


  expandButton(button){

    const url=

        button
            ?.dataset
            ?.certUrl

        ||"";


    this.expandDoc(
        url
    );
  },


  expandDoc(url){

    const safeUrl=
        certSafeUrl(
            url
        );


    if(!safeUrl){

      return;
    }


    const root=

        document.getElementById(
            "cert-expand-root"
        )

        ||

        (()=>{

          const d=
              document.createElement(
                  "div"
              );


          d.id=
              "cert-expand-root";


          document.body.appendChild(
              d
          );


          return d;

        })();


    root.innerHTML=`

      <div
        class="cert-expand-ov"
        onclick="certsUI.closeExpand()">
      </div>


      <div class="cert-expand-box">


        <button
          class="cert-expand-x"
          type="button"
          onclick="certsUI.closeExpand()">

          ✕

        </button>


        <iframe
          src="${certEsc(safeUrl)}#toolbar=0&navpanes=0"
          loading="lazy">
        </iframe>


      </div>
    `;
  },


  closeExpand(){

    const root=
        document.getElementById(
            "cert-expand-root"
        );


    if(root){

      root.innerHTML=
          "";
    }
  }

};


certsLoad();