/* Al-Attar — product-detail.js
   Standalone product page.
   Includes:
   - Safe HTML escaping
   - Safe image URLs
   - Safe ingredient tabs
   - Product badge lookup
   - Arabic / English badge labels
*/


/* =========================================================
   TEXT
========================================================= */

const PD_T={

    ar:{

        ingredients:"المكوّنات:",
        benefits:"الفوائد:",
        quickBuy:"أضف للسلة",
        certsTitle:"معتمد من",

        notFoundTitle:"المنتج غير موجود",
        notFoundBody:"ممكن يكون هذا المنتج انحذف أو توقف مؤقتاً.",
        backToShop:"العودة للمتجر",

        home:"الرئيسية",
        shop:"المتجر",

        ingInfoTitle:"لمحة عن المكوّنات",
        ingBenefits:"الفوائد العشبية",
        ingCommon:"أسماء أخرى",
        ingFamily:"الفصيلة",
        ingParts:"الجزء المستخدم"

    },


    en:{

        ingredients:"Ingredients:",
        benefits:"Benefits:",
        quickBuy:"Add to Cart",
        certsTitle:"Certified by",

        notFoundTitle:"Product not found",
        notFoundBody:
            "This product may have been removed or is temporarily unavailable.",

        backToShop:"Back to Shop",

        home:"Home",
        shop:"Shop",

        ingInfoTitle:"A Closer Look at the Ingredients",
        ingBenefits:"Herbal Benefits",
        ingCommon:"Common Names",
        ingFamily:"Family",
        ingParts:"Parts Used"

    }

};


/* =========================================================
   PRODUCT BADGES
========================================================= */

const PD_BADGES={

    popular:{
        ar:"شائع",
        en:"Popular"
    },

    best_seller:{
        ar:"الأكثر مبيعاً",
        en:"Best Seller"
    },

    new:{
        ar:"جديد",
        en:"New"
    },

    recommended:{
        ar:"موصى به",
        en:"Recommended"
    },

    limited:{
        ar:"كمية محدودة",
        en:"Limited"
    }

};


function pdBadgeLabel(
    value,
    lang
){

    if(!value){
        return "";
    }


    const badge=
        PD_BADGES[value];


    /*
      Support old values already stored
      before we changed the admin field
      to a dropdown.
    */

    if(!badge){

        return String(
            value
        );
    }


    return (
        badge[lang]||
        badge.en||
        String(value)
    );
}


/* =========================================================
   LANGUAGE
========================================================= */

function pdLang(){

    try{

        return (
            localStorage.getItem(
                "attar_lang"
            )||
            "ar"
        );

    }catch(e){

        return "ar";
    }
}


/* =========================================================
   PRICE
========================================================= */

function pdFmt(
    n,
    L
){

    return (
        Number(
            n||0
        )
            .toFixed(2)
        +
        (
            L==="ar"
                ?" د.أ"
                :" JD"
        )
    );
}


/* =========================================================
   SECURITY HELPERS
========================================================= */

function pdEsc(value){

    return String(
        value??""
    )

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );
}


function pdSafeUrl(value){

    const raw=
        String(
            value??""
        )
            .trim();


    if(!raw){

        return "";
    }


    try{

        const url=
            new URL(
                raw,
                window.location.origin
            );


        if(
            url.protocol!=="http:" &&
            url.protocol!=="https:"
        ){

            return "";
        }


        return url.href;


    }catch(e){

        return "";
    }
}


/* =========================================================
   NOT FOUND
========================================================= */

function pdNotFoundHtml(){

    const L=
        pdLang();

    const T=
        PD_T[L];


    return `

    <div class="pd-empty">

      <h1>
        ${T.notFoundTitle}
      </h1>


      <p>
        ${T.notFoundBody}
      </p>


      <a
        class="cta-btn"
        href="index.html">

        ${T.backToShop}

      </a>

    </div>

  `;
}


/* =========================================================
   LOAD PRODUCT
========================================================= */

async function pdLoad(){

    const root=
        document.getElementById(
            "product-root"
        );


    if(!root){

        return;
    }


    const params=
        new URLSearchParams(
            location.search
        );


    const id=
        params.get(
            "id"
        );


    if(!id){

        root.innerHTML=
            pdNotFoundHtml();

        return;
    }


    try{

        const [

            prodRes,
            catRes,
            benRes,
            ingRes

        ]=await Promise.all([


            sb
                .from(
                    "products"
                )

                .select("*")

                .eq(
                    "id",
                    id
                )

                .eq(
                    "active",
                    true
                )

                .single(),


            sb
                .from(
                    "category_labels"
                )

                .select("*"),


            sb
                .from(
                    "benefit_labels"
                )

                .select("*"),


            sb
                .from(
                    "ingredient_labels"
                )

                .select("*")

        ]);


        if(
            prodRes.error ||
            !prodRes.data
        ){

            console.error(
                "product load error:",
                prodRes.error
            );


            root.innerHTML=
                pdNotFoundHtml();


            return;
        }


        const CATS={};
        const BEN={};
        const ING={};


        (
            catRes.data||
            []
        )
            .forEach(
                row=>{

                    CATS[row.key]={

                        ar:
                        row.ar,

                        en:
                        row.en,

                        ic:
                            row.icon||
                            "🌿"

                    };

                }
            );


        (
            benRes.data||
            []
        )
            .forEach(
                row=>{

                    BEN[row.key]={

                        ar:
                        row.ar,

                        en:
                        row.en

                    };

                }
            );


        (
            ingRes.data||
            []
        )
            .forEach(
                row=>{

                    ING[row.key]=
                        row;

                }
            );


        pdRender(

            prodRes.data,

            CATS,

            BEN,

            ING

        );


    }catch(err){

        console.error(
            "product detail load error:",
            err
        );


        root.innerHTML=
            pdNotFoundHtml();
    }
}


/* =========================================================
   INGREDIENT INFORMATION
========================================================= */

function pdIngredientTabsHtml(
    r,
    ING,
    L
){

    const T=
        PD_T[L];


    const keys=
        (
            r.ingredients||
            []
        )
            .filter(
                key=>{

                    const ing=
                        ING[key];


                    return (

                        ing &&

                        (
                            ing.desc_ar ||
                            ing.desc_en ||
                            ing.scientific_name
                        )

                    );
                }
            );


    if(
        !keys.length
    ){

        return "";
    }


    /* =======================================================
       PANES
    ======================================================= */

    const panes=
        keys

            .map(
                (
                    key,
                    index
                )=>{

                    const ing=
                        ING[key];


                    const name=

                        L==="ar"

                            ?(
                                ing.ar||
                                ing.en||
                                key
                            )

                            :(
                                ing.en||
                                ing.ar||
                                key
                            );


                    const desc=

                        L==="ar"

                            ?(
                                ing.desc_ar||
                                ""
                            )

                            :(
                                ing.desc_en||
                                ing.desc_ar||
                                ""
                            );


                    const commonNames=

                        L==="ar"

                            ?(
                                ing.common_names_ar||
                                ""
                            )

                            :(
                                ing.common_names_en||
                                ing.common_names_ar||
                                ""
                            );


                    const family=

                        L==="ar"

                            ?(
                                ing.family_ar||
                                ""
                            )

                            :(
                                ing.family_en||
                                ing.family_ar||
                                ""
                            );


                    const parts=

                        L==="ar"

                            ?(
                                ing.parts_used_ar||
                                ""
                            )

                            :(
                                ing.parts_used_en||
                                ing.parts_used_ar||
                                ""
                            );


                    const benefits=

                        (
                            L==="ar"

                                ?ing.benefits_ar

                                :ing.benefits_en

                        )

                        ||[];


                    const imageUrl=
                        pdSafeUrl(
                            ing.image_url
                        );


                    const factsRows=[


                        commonNames

                            ?`
                        <div class="ping-fact">

                          <b>
                            ${T.ingCommon}
                          </b>

                          <span>
                            ${pdEsc(commonNames)}
                          </span>

                        </div>
                      `

                            :"",


                        family

                            ?`
                        <div class="ping-fact">

                          <b>
                            ${T.ingFamily}
                          </b>

                          <span>
                            ${pdEsc(family)}
                          </span>

                        </div>
                      `

                            :"",


                        parts

                            ?`
                        <div class="ping-fact">

                          <b>
                            ${T.ingParts}
                          </b>

                          <span>
                            ${pdEsc(parts)}
                          </span>

                        </div>
                      `

                            :""

                    ]
                        .join("");


                    return `

                  <div
                    class="ping-pane"
                    data-ping-pane="${pdEsc(key)}"
                    style="${
                        index===0
                            ?""
                            :"display:none"
                    }">


                    <div class="ping-pane-text">


                      <h3>
                        ${pdEsc(name)}
                      </h3>


                      ${
                        ing.scientific_name

                            ?`
                              <i class="ping-sci">

                                ${
                                pdEsc(
                                    ing.scientific_name
                                )
                            }

                              </i>
                            `

                            :""
                    }


                      ${
                        desc

                            ?`
                              <p>
                                ${pdEsc(desc)}
                              </p>
                            `

                            :""
                    }


                      ${
                        benefits.length

                            ?`

                              <div class="ping-sub">

                                ${T.ingBenefits}

                              </div>


                              <ul class="ping-benefits">

                                ${
                                benefits

                                    .map(
                                        benefit=>`

                                            <li>
                                              ${pdEsc(benefit)}
                                            </li>

                                          `
                                    )

                                    .join("")
                            }

                              </ul>

                            `

                            :""
                    }


                      ${
                        factsRows

                            ?`
                              <div class="ping-facts">

                                ${factsRows}

                              </div>
                            `

                            :""
                    }


                    </div>


                    ${
                        imageUrl

                            ?`

                            <div class="ping-pane-img">

                              <img
                                src="${pdEsc(imageUrl)}"
                                alt="${pdEsc(name)}"
                                loading="lazy">

                            </div>

                          `

                            :""
                    }


                  </div>

                `;
                }
            )

            .join("");


    /* =======================================================
       TABS
    ======================================================= */

    const tabs=
        keys

            .map(
                (
                    key,
                    index
                )=>{

                    const ing=
                        ING[key];


                    const name=

                        L==="ar"

                            ?(
                                ing.ar||
                                ing.en||
                                key
                            )

                            :(
                                ing.en||
                                ing.ar||
                                key
                            );


                    return `

                  <button
                    class="ping-tab${
                        index===0
                            ?" active"
                            :""
                    }"

                    data-ping-tab="${pdEsc(key)}"

                    onclick="pdSwitchIngTab(
                        this.dataset.pingTab
                    )"

                    type="button">

                    ${pdEsc(name)}

                  </button>

                `;
                }
            )

            .join("");


    return `

    <div class="pd-ingredients">


      <h2 class="pd-section-title">

        ${T.ingInfoTitle}

      </h2>


      <div class="ping-tabs">

        ${tabs}

      </div>


      <div class="ping-panes">

        ${panes}

      </div>


    </div>

  `;
}


/* =========================================================
   SWITCH INGREDIENT TAB
========================================================= */

function pdSwitchIngTab(key){

    document
        .querySelectorAll(
            "[data-ping-tab]"
        )

        .forEach(
            btn=>{

                btn.classList.toggle(

                    "active",

                    btn.dataset.pingTab===
                    key

                );

            }
        );


    document
        .querySelectorAll(
            "[data-ping-pane]"
        )

        .forEach(
            pane=>{

                pane.style.display=

                    pane.dataset.pingPane===
                    key

                        ?""

                        :"none";

            }
        );
}


/* =========================================================
   RENDER PRODUCT
========================================================= */

function pdRender(
    r,
    CATS,
    BEN,
    ING
){

    const L=
        pdLang();


    const T=
        PD_T[L];


    const root=
        document.getElementById(
            "product-root"
        );


    if(!root){

        return;
    }


    const name=

        L==="ar"

            ?(
                r.name_ar||
                r.name_en||
                ""
            )

            :(
                r.name_en||
                r.name_ar||
                ""
            );


    const desc=

        L==="ar"

            ?(
                r.desc_ar||
                ""
            )

            :(
                r.desc_en||
                r.desc_ar||
                ""
            );


    const catInfo=

        CATS[
            r.category
            ]

        ||{

            ar:
            r.category,

            en:
            r.category,

            ic:
                "🌿"

        };


    const catName=

        catInfo[L]||

        catInfo.ar||

        r.category||

        "";


    /* =======================================================
       MAIN IMAGE
    ======================================================= */

    const imageUrl=
        pdSafeUrl(
            r.image_url
        );


    const imageHtml=

        imageUrl

            ?`

            <img
              src="${pdEsc(imageUrl)}"
              alt="${pdEsc(name)}"
              loading="lazy">

          `

            :`

            <span class="ph">

              ${pdEsc(
                catInfo.ic||
                "🌿"
            )}

            </span>

          `;


    /* =======================================================
       BADGE
    ======================================================= */

    const badgeLabel=
        pdBadgeLabel(
            r.badge_text,
            L
        );


    const badgeHtml=

        badgeLabel

            ?`

            <span class="pcard-badge">

              ${pdEsc(badgeLabel)}

            </span>

          `

            :"";


    /* =======================================================
       INGREDIENT PILLS
    ======================================================= */

    const ingredientsHtml=

        (
            r.ingredients||
            []
        )

            .map(
                key=>{

                    const value=

                        ING[key]

                            ?(
                                ING[key][L]||
                                ING[key].ar||
                                key
                            )

                            :key;


                    return `

                  <span class="mpill">

                    ${pdEsc(value)}

                  </span>

                `;
                }
            )

            .join("");


    /* =======================================================
       BENEFIT PILLS
    ======================================================= */

    const benefitsHtml=

        (
            r.benefits||
            []
        )

            .map(
                key=>{

                    const value=

                        BEN[key]

                            ?(
                                BEN[key][L]||
                                BEN[key].ar||
                                key
                            )

                            :key;


                    return `

                  <span class="mpill">

                    ${pdEsc(value)}

                  </span>

                `;
                }
            )

            .join("");


    /* =======================================================
       GALLERY
    ======================================================= */

    const galleryItems=

        (
            r.gallery||
            []
        )

            .map(
                item=>{

                    const url=
                        pdSafeUrl(
                            item?.url
                        );


                    if(!url){

                        return "";
                    }


                    const label=
                        item?.label||
                        "";


                    return `

                  <div class="pd-gallery-item">


                    <img
                      src="${pdEsc(url)}"
                      alt="${
                        pdEsc(
                            label||
                            name
                        )
                    }"
                      loading="lazy">


                    ${
                        label

                            ?`
                            <span>
                              ${pdEsc(label)}
                            </span>
                          `

                            :""
                    }


                  </div>

                `;
                }
            )

            .filter(Boolean)

            .join("");


    const galleryHtml=

        galleryItems

            ?`

            <div class="pd-gallery">

              <div class="pd-gallery-grid">

                ${galleryItems}

              </div>

            </div>

          `

            :"";


    /* =======================================================
       INGREDIENT DETAILS
    ======================================================= */

    const ingredientTabsHtml=
        pdIngredientTabsHtml(

            r,

            ING,

            L

        );


    /* =======================================================
       TITLE
    ======================================================= */

    document.title=
        `${
            name||
            "Product"
        } | العطّار`;


    /* =======================================================
       HTML
    ======================================================= */

    root.innerHTML=`

    <div class="pd-crumb">


      <a href="index.html">
        ${T.home}
      </a>


      /


      <a href="index.html">
        ${T.shop}
      </a>


      /


      ${pdEsc(name)}


    </div>


    <div class="pd-layout">


      <div class="pd-imgwrap">


        ${badgeHtml}


        ${imageHtml}


      </div>


      <div class="pd-info">


        <div class="pd-cat">

          ${pdEsc(catName)}

        </div>


        <h1 class="pd-name">

          ${pdEsc(name)}

        </h1>


        ${
        desc

            ?`

                <p class="pd-desc">

                  ${pdEsc(desc)}

                </p>

              `

            :""
    }


        <div class="pd-price">

          ${
        pdFmt(
            r.price,
            L
        )
    }

        </div>


        ${
        ingredientsHtml

            ?`

                <div class="msect">

                  ${T.ingredients}

                </div>


                <div class="mpills">

                  ${ingredientsHtml}

                </div>

              `

            :""
    }


        ${
        benefitsHtml

            ?`

                <div class="msect">

                  ${T.benefits}

                </div>


                <div class="mpills">

                  ${benefitsHtml}

                </div>

              `

            :""
    }


        <button
          class="quickbuy pd-quickbuy"
          type="button"

          data-product-id="${
        pdEsc(
            String(
                r.id??
                ""
            )
        )
    }"

          onclick="
            location.href=
              'index.html?add='+
              encodeURIComponent(
                this.dataset.productId
              )
          ">

          <span>
            ${T.quickBuy}
          </span>

        </button>


      </div>


    </div>


    ${galleryHtml}


    ${ingredientTabsHtml}


    <div class="pd-certs">


      <div class="pd-certs-title">

        ${T.certsTitle}

      </div>


      ${
        typeof certsRowHtml==="function"

            ?certsRowHtml()

            :""
    }


    </div>

  `;
}


/* =========================================================
   START
========================================================= */

pdLoad();